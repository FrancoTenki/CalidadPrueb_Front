it('iniciar sesion como cosumidor',()=>{
    cy.visit('http://localhost:3000/')
  cy.contains('Login').click()
  cy.get('input#InputLoUsername').type('franco')
  cy.get('input#InputLoPass').type('123')
  cy.get('button#btnLoginIncicoSecion').click()
})