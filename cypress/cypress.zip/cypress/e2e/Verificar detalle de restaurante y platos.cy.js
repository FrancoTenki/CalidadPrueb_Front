
it('Verificar detalle de restaurante y platos', () => {
    cy.visit('http://localhost:3000/')
    cy.contains('restaurantes').click() 
    cy.get('div #Card_Restaurante').first().click()
    cy.get('div H2#H2_Nombre_Restaurante_Detalle').should('have.text', 'Milos Broaster Alex')
    cy.get('div H3#H3_Direccion_Restaurante_Detalle').should('have.text', 'Av San Martín de Porres 792, Cajamarca 06003, Peru')
    cy.get('div #Card_Plato div div h4').first().should('have.text', 'Mostrito 1/8 más Gaseosa')
})