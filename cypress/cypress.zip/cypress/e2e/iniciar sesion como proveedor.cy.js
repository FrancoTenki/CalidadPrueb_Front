describe('Pruebas', () => {
  
    it('iniciar sesion como proveedor',()=>{
      cy.visit('http://localhost:3000/')
      cy.contains('Login').click()
      cy.get('input#InputLoUsername').type('alex')
      cy.get('input#InputLoPass').type('123')
      cy.get('button#btnLoginIncicoSecion').click()
    })
})
