
it('Contar los restaurantes en el home', () => {
    cy.visit('http://localhost:3000/')
    cy.contains('restaurantes').click() 
    cy.get('div #Card_Restaurante').should('have.length', 7)
    //el primeor con milos broaster
    cy.get('div #Card_Restaurante a div p').first().should('have.text', 'Milos Broaster Alex')
})