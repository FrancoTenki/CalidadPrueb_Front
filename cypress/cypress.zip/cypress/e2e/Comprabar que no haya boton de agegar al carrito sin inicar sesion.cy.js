it('Comprabar que no haya boton de agegar al carrito sin inicar sesion',()=>{
    cy.visit('http://localhost:3000/')
    cy.contains('restaurantes').click() 
  cy.get('div #Card_Restaurante').first().click()
  cy.get('div #Card_Plato').should('have.length',2)
  cy.get('div #Card_Plato h4#H4_Nombre_plato').first().should('have.text','Mostrito 1/8 más Gaseosa')
  cy.get('div #Card_Plato p#PNeedLogin').first().should('have.text','Inicie secion para agregar al carrito')
})