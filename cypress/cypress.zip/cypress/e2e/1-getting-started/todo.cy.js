/// <reference types="cypress" />

// Cypress Pruebas para delivery

describe('Pruebas', () => {
  beforeEach(() => {
  })
})
